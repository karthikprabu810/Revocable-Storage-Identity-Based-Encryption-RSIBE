/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author PG
 */
package IBEencryption;

public class Node {
    public String fileOwnerName;
    public String fileName;
    public String username;
    public long revocationTime;

    public Node(String fileOwnerName, String fileName, String username, long revocationTime) {
        this.fileOwnerName = fileOwnerName;
        this.fileName = fileName;
        this.username = username;
        this.revocationTime = revocationTime;
    }
}
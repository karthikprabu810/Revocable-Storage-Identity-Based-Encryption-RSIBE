/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author PG
 */


//KUNodes.java
package IBEencryption;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
public class KUNodes {

    public static Set<Node> Y = new HashSet<Node>();
    public static Set<Node> Z = new HashSet<Node>();
    public static void implementKUNodes(List<Node> RL, long currTimePeriod) {
        Set<String> X = new HashSet<String>();

        for(Node currNode: RL) {
            if(currNode.revocationTime <= currTimePeriod) {
                X.add(currNode.fileName);
                Z.add(currNode);
                
            } //else if(X.contains(currNode.fileName)) {
            else{    
                Y.add(currNode);
            }
        }
    }

    public static void main(String[] args) {
        List<Node> RL = new ArrayList<Node>();

        for(int nodeId = 0; nodeId < 7; nodeId++) {
            char ch = 'a';
            String fileName = "a" + nodeId + ".txt";
            Node node = new Node("u1", fileName, Character.toString(ch), 10);
            RL.add(node);
            ch++;
        }

        for(Node currNode: Y) {
            System.out.println("UserName: " + currNode.username);
            System.out.println("FileName: " + currNode.fileName);
        }

    }
}